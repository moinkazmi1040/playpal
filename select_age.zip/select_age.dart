import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:google_fonts/google_fonts.dart';

class ContAsPlayer extends StatefulWidget {
  const ContAsPlayer({Key? key}) : super(key: key);

  @override
  State<ContAsPlayer> createState() => _ContAsPlayerState();
}

class _ContAsPlayerState extends State<ContAsPlayer> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    var height = size.height;
    var width = size.width;

    List ages = ['13', '16', '17', '18', '19', '21', '22'];
    return Scaffold(
      body: SafeArea(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            // i
            gradient: LinearGradient(
              colors: [
                Color.fromARGB(255, 80, 6, 95),
                Color.fromARGB(255, 39, 2, 63),
              ],
              begin: Alignment.bottomRight,
              end: Alignment.topLeft,
            ),
          ),
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              Container(
                width: width * .85,
                height: height * .09,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        width: width * .12,
                        height: height * .05,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 58, 6, 88),
                          // boxShadow: [
                          //   BoxShadow(
                          //     color: Color.fromARGB(171, 131, 27, 79)
                          //         .withOpacity(0.5),
                          //     spreadRadius: 2,
                          //     blurRadius: 2,
                          //     offset: Offset(0, 2), // changes position of shadow
                          //   ),
                          // ],
                          borderRadius: BorderRadius.all(
                            Radius.circular(10),
                          ), //BorderRadius.all
                        ),
                        child: Icon(
                          Icons.arrow_back_ios_new_sharp,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 15,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                width: width * .85,
                height: height * .05,
                child: Row(
                  children: [
                    Text(
                      'Select Age',
                      style: GoogleFonts.syne(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 30,
              ),
              Container(
                width: width * .90,
                height: height * .10,
                child: TextField(
                  decoration: InputDecoration(
                      prefixIcon: Icon(
                        FontAwesomeIcons.user,
                        size: 18,
                        color: Colors.white54,
                      ),
                      filled: true,
                      fillColor: Color.fromARGB(255, 179, 11, 95).withOpacity(0.5),
                      border: OutlineInputBorder(
                          borderSide: BorderSide.none,
                          borderRadius: BorderRadius.circular(10)),
                      hintStyle: TextStyle(color: Colors.white38),
                      hintText: "Type your age between 13-50 ",
                      labelStyle:
                          GoogleFonts.syne(color: Colors.white, fontSize: 16)),
                ),
              ),

              Container(
                width: width * .90,
                height: height * .05,
                child: Row(
                  children: [
                    Text(
                      'What do you play?',
                      style: GoogleFonts.syne(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: Colors.white),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
SizedBox(

  height: 20,
),
              Container(
                width: width * .85,
                height: height * .08,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Container(
                      width: width * .40,
                      height: height * .06,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 179, 11, 95).withOpacity(0.5),
                        // boxShadow: [
                        //   BoxShadow(
                        //     color: Color.fromARGB(255, 107, 13, 145)
                        //         .withOpacity(0.5),
                        //     spreadRadius: 2,
                        //     blurRadius: 7,
                        //     offset: Offset(0, 3), // changes position of shadow
                        //   ),
                        // ],
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ), //BorderRadius.all
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            FontAwesomeIcons.soccerBall,
                            color: Colors.white,
                            size: 25,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Football',
                            style: GoogleFonts.syne(color: Colors.white, fontSize: 16),
                          )
                        ],
                      ),
                    ),
                    Container(
                      width: width * .40,
                      height: height * .06,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 58, 6, 88),
                        // boxShadow: [
                        //   BoxShadow(
                        //     color: Color.fromARGB(255, 179, 11, 95)
                        //         .withOpacity(0.5),
                        //     spreadRadius: 2,
                        //     blurRadius: 7,
                        //     offset: Offset(0, 3), // changes position of shadow
                        //   ),
                        // ],
                        borderRadius: BorderRadius.all(
                          Radius.circular(10),
                        ), //BorderRadius.all
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            FontAwesomeIcons.baseball,
                            color: Colors.white,
                            size: 25,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Text(
                            'Cricket',
                            style:GoogleFonts.syne(color: Colors.white, fontSize: 16),
                          )
                        ],
                      ),
                    )
                  ],
                ),
              ),

              SizedBox(
                height: 60,
              ),
              DecoratedBox(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFFFFFFFF),
                      Color.fromARGB(0, 255, 255, 255),
                    ],
                  ),
                ),
                child: Container(
                  width: width*.90,
                  height: 86,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFF570A57),
                        Color(0xFFF806CC),
                      ],
                    ),
                  ),
                  margin:
                  const EdgeInsets.fromLTRB(1.0, 1.0, 1.0, 4.0),


                    child:  Row(

                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Sign in",
                          style: GoogleFonts.syne(color: Colors.white,fontSize: 16),
                        ),
                      ],
                    ),

                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
